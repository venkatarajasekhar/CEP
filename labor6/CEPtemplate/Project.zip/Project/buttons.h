#ifndef BUTTONS_H_
#define BUTTONS_H_ 

void read_buttons(void) {
}

#endif /* BUTTONS_ */
