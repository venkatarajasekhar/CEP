#ifndef LABOR6_H_
#define LABOR6_H_

#define ARM_ADS

void labor6(void);

#endif /* LABOR6_ */
