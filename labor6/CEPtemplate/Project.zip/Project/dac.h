#ifndef DAC_H_
#define DAC_H_

#include <stdint.h>

void dac_setup(void);
void dac_set(uint16_t val);

#endif /* DAC_H_ */
